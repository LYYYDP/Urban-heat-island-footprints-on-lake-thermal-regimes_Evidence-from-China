import os
import shutil
import subprocess
import logging

# Configuration Log
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')


class Air2StreamProcessor:
    def __init__(self):
        # Initialize path configuration
        self.base_path = r" " #Your file directory
        self.switzerland_path = os.path.join(self.base_path, 'Superior')
        self.output_paths = {
            'cc': os.path.join(self.base_path, ' ', ' '),
            'cv': os.path.join(self.base_path, ' ', ' '),
            'cc_input': os.path.join(self.base_path, ' ', ' '),
            'cv_input': os.path.join(self.base_path, ' ', ' '),
            'params_forward': self.switzerland_path
        }

        # Create output directory
        for path in self.output_paths.values():
            os.makedirs(path, exist_ok=True)

    def modify_input_file(self, station_id: int):
        """Dynamically modify the input.txt file"""
        input_file = os.path.join(self.base_path, 'input.txt')

        try:
            with open(input_file, 'r') as f:
                lines = f.readlines()

            if len(lines) >= 4:
                lines[3] = f"{station_id}    ! name/ID of the water temperature station\n"

            with open(input_file, 'w') as f:
                f.writelines(lines)

            logging.info(f"Updated input.txt for station {station_id}")

        except Exception as e:
            logging.error(f"Failed to modify input.txt: {str(e)}")
            raise

    def copy_station_files(self, station_id: int):
        "Copy related files of the website"
        station_folder = os.path.join(self.switzerland_path, str(station_id))
        required_files = {
            'cc': f'stndrck_{station_id}_cc.txt',
            'cv': f'stndrck_{station_id}_cv.txt',
            'params_forward': 'parameters_forward.txt'
        }

        try:
            for file_type, filename in required_files.items():
                src = os.path.join(station_folder, filename)
                dest = self.switzerland_path

                if os.path.exists(src):
                    shutil.copy(src, dest)
                    logging.debug(f"Copied {filename} to {dest}")
                else:
                    logging.warning(f"File not found: {src}")

        except Exception as e:
            logging.error(f"Failed to copy the file: {str(e)}")
            raise

    def run_air2stream(self):
        """Execute an external program"""
        exe_path = os.path.join(self.base_path, 'air2water_v2.0.exe')
        input_file = os.path.join(self.base_path, 'input.txt')

        try:
            # Use Command Redirection
            result = subprocess.run(
                [exe_path],
                stdin=open(input_file, 'r'),
                capture_output=True,
                text=True,
                cwd=self.base_path
            )

            logging.info(f"Model running status: {result.returncode}")
            if result.returncode != 0:
                logging.error(f"Model error output:\n{result.stderr}")
                return False

            logging.debug(f"Model output:\n{result.stdout}")
            return True

        except Exception as e:
            logging.error(f"Execution of the model failed: {str(e)}")
            return False

    def handle_outputs(self, station_id: int):
        """Handle the output file"""
        output_dir = os.path.join(self.switzerland_path, 'output_1')
        file_patterns = {
            'cc': f'2_FORWARD_RMS_stndrck_{station_id}_cc_1d.out',
            'cv': f'3_FORWARD_RMS_stndrck_{station_id}_cv_1d.out',
            'cc_input': f'4_FORWARD_RMS_stndrck_{station_id}_cc_1d.out',
            'cv_input': f'5_FORWARD_RMS_stndrck_{station_id}_cv_1d.out',
        }

        success = True
        try:
            for file_type, pattern in file_patterns.items():
                src = os.path.join(output_dir, pattern)
                dest = self.output_paths[file_type]

                if os.path.exists(src):
                    shutil.copy(src, dest)
                    logging.info(f"Successful replication {pattern} To {dest}")
                else:
                    logging.error(f"Output file not found: {src}")
                    success = False

        except Exception as e:
            logging.error(f"Failed to process the output file: {str(e)}")
            success = False

        return success

    def cleanup(self):
        """Delete temporary files"""
        try:
            # Clean up the output directory
            output_5 = os.path.join(self.switzerland_path, 'output_1')
            if os.path.exists(output_5):
                shutil.rmtree(output_5, ignore_errors=True)
                logging.debug("The output_5 directory has been cleared.")

            # Delete the temporary text files (keep parameters.txt)
            for fname in os.listdir(self.switzerland_path):
                if fname.endswith('.txt') and fname != 'parameters.txt':
                    os.remove(os.path.join(self.switzerland_path, fname))
                    logging.debug(f"Temporary files have been deleted.: {fname}")

        except Exception as e:
            logging.error(f"Cleanup failed: {str(e)}")

    def process_station(self, station_id: int):
        """Handling a single monitoring station"""
        logging.info(f"Start processing the monitoring station {station_id}")

        try:
            # 1. Modify the input file
            self.modify_input_file(station_id)

            # 2. Copy the relevant files
            self.copy_station_files(station_id)

            # 3. Ensure that the output directory exists
            output_5_dir = os.path.join(self.switzerland_path, 'output_1')
            os.makedirs(output_5_dir, exist_ok=True)

            # 4. Run the model
            if not self.run_air2stream():
                return False

            # 5. Handling of Output
            if not self.handle_outputs(station_id):
                return False

            return True

        except Exception as e:
            logging.error(f"Handling monitoring stations {station_id} A serious error occurred at that time: {str(e)}")
            return False

        finally:
            # 6. Clean up temporary files
            self.cleanup()
            logging.info(f"Completion of monitoring station {station_id} The handling of it")


def main():
    processor = Air2StreamProcessor()
    failed_stations = []

    # Handle all monitoring stations
    for station_id in range(1, 217):
        success = processor.process_station(station_id)
        if not success:
            failed_stations.append(station_id)

    # Generate Final Report
    if not failed_stations:
        logging.info("All monitoring stations have been processed successfully!")
    else:
        logging.warning(f"The following monitoring stations experienced processing failures: {failed_stations}")


if __name__ == "__main__":
    main()
