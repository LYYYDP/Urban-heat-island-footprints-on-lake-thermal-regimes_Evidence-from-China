import os
import subprocess
from concurrent.futures import ProcessPoolExecutor, as_completed

# Set the root directory path and the path of the model execution file
root_dir = r" "  #Your file directory
model_exe = 'air2water_v2.0.exe'

def run_model(folder, i):
    if os.path.exists(folder):
        print(f"Running model in folder {i}...")
        os.chdir(folder)

        try:
            # Execution Model
            result = subprocess.run([model_exe], capture_output=True, text=True)

            # Output Execution Result
            if result.returncode == 0:
                print(f"Model run completed for folder {i}")
                print(result.stdout)  # Output to standard output
            else:
                print(f"Error occurred in folder {i}: {result.stderr}")
        except Exception as e:
            print(f"Failed to run model in folder {i}: {str(e)}")
    else:
        print(f"Folder {i} does not exist.")

    print("-" * 40)
    return i

if __name__ == "__main__":
    folders = [os.path.join(root_dir, f"{i}") for i in range(1, 217)]

    with ProcessPoolExecutor() as executor:
        futures = [executor.submit(run_model, folder, i) for i, folder in enumerate(folders, start=1)]

        for future in as_completed(futures):
            try:
                future.result()
            except Exception as e:
                print(f"Error in future: {e}")

    print("All simulations completed.")